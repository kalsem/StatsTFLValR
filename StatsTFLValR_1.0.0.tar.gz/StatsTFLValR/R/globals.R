utils::globalVariables(c("..TRT..", "n", "pct", "value", "stat"))
utils::globalVariables(c(".data", "N", "n_", "result", "sas_round", ":="))
utils::globalVariables(c(
    "mean_", "sd_", "min_", "max_", "Q1", "Q3",
    "median_", "n1", "mn", "sd", "med1", "Q1_Q3", "mn_mx"
  ))
utils::globalVariables(c("sort_n", "sec_ord", "sort_ord", "uncoded","HAS_NUM",
                         "GRADE_LAB", "_SUBVARLBL_", "psec_ord"))
utils::globalVariables(c(
  # data.table special symbols
  ".SD", ".N",

  # data.table ..-prefixed variables used for NSE
  "..by_vars", "..common_cols", "..vars_to_use",

  # columns you create on-the-fly
  "_TYPE_", "_OBS_"
))
